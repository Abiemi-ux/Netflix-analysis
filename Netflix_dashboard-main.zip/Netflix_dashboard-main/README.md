# Netflix_dashboard
-This is a Data visualization project made on Tableau by me.

-For live interaction, the link to this dashboard is: https://public.tableau.com/views/Netflixdashboard_17022882306410/Netflix?:language=en-US&:display_count=n&:origin=viz_share_link

-Check out my other dashboards on Tableau: https://public.tableau.com/app/profile/pranita.patil2495/vizzes

-Reference: Youtube channel-DataScience RoadMap
